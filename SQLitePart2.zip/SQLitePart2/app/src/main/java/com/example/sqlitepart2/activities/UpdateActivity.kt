package com.example.sqlitepart2.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.sqlitepart2.R
import com.example.sqlitepart2.database.DBHelper
import com.example.sqlitepart2.models.Employee
import kotlinx.android.synthetic.main.activity_update.*

class UpdateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        init()
    }

    private fun init(){

        button_update.setOnClickListener{

            var dbHelper = DBHelper(this)

            var id = edit_text_id.text.toString()
            var name = edit_text_name.text.toString()
            var email = edit_text_email.text.toString()

            var employee : Employee = Employee(id.toInt(), name, email)

            dbHelper.updateEmployee(employee)
        }
    }

}
