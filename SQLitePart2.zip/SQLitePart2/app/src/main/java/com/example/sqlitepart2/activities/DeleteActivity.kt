package com.example.sqlitepart2.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.sqlitepart2.R
import com.example.sqlitepart2.database.DBHelper
import com.example.sqlitepart2.models.Employee
import kotlinx.android.synthetic.main.activity_delete.*

class DeleteActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete)

        init()
    }
    private fun init(){

        button_delete.setOnClickListener{

            var dbHelper = DBHelper(this)

            var employee = Employee(edit_text_id.text.toString().toInt(), "", "")

            dbHelper.deleteEmployee(employee)
        }
    }
}
