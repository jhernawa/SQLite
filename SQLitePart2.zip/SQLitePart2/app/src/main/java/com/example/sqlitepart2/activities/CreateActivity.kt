package com.example.sqlitepart2.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.sqlitepart2.R
import com.example.sqlitepart2.database.DBHelper
import com.example.sqlitepart2.models.Employee
import kotlinx.android.synthetic.main.activity_create.*

class CreateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create)

        init()
    }

    private fun init() {
        button_create.setOnClickListener{
            var id = edit_text_id.text.toString()
            var name = edit_text_name.text.toString()
            var email = edit_text_email.text.toString()

            var employee = Employee(id.toInt(), name, email)

            var dbHelper = DBHelper(this)
            dbHelper.createEmployee(employee)
            Toast.makeText(this, "inserted", Toast.LENGTH_SHORT).show()


        }

    }
}
