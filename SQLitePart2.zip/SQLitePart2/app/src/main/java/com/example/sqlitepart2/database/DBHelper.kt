package com.example.sqlitepart2.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.sqlitepart2.models.Employee

class DBHelper(var mContext: Context) :
    SQLiteOpenHelper(mContext, DATABASE_NAME, null, DATABASE_VERSION_CODE) {

    var database: SQLiteDatabase = writableDatabase
    companion object {
        private const val DATABASE_NAME = "mydatabase"
        private const val TABLE_NAME = "employee"
        private const val DATABASE_VERSION_CODE = 8
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_EMAIL = "email"

    }

    override fun onCreate(database: SQLiteDatabase?) {
        val createTable =
            "create table $TABLE_NAME (" +
                    "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COLUMN_NAME char(50), " +
                    "$COLUMN_EMAIL char(50))"
        Log.e("data", createTable)
        database?.execSQL(createTable)
    }

    override fun onUpgrade(database: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        var dropTable = "drop table $TABLE_NAME"
        database?.execSQL(dropTable)
        onCreate(database)
    }

    fun createEmployee(newEmployee: Employee){

        var contentValues = ContentValues()
        contentValues.put(COLUMN_ID, newEmployee.id)
        contentValues.put(COLUMN_NAME, newEmployee.name)
        contentValues.put(COLUMN_EMAIL, newEmployee.email)
        var x = database.insert(TABLE_NAME, null, contentValues)
        Log.e("data", x.toString())
    }

    fun readEmployee(): ArrayList<Employee>{
        var mList: ArrayList<Employee> = ArrayList()

        return mList
    }

    fun updateEmployee(updateEmployee: Employee){
        var whereClause = "$COLUMN_ID"
        var whereArgs = arrayOf(updateEmployee.id.toString())
        var contentValues = ContentValues()
        contentValues.put(COLUMN_NAME, updateEmployee.name)
        contentValues.put(COLUMN_EMAIL, updateEmployee.email)
        database.update(TABLE_NAME, contentValues, whereClause, whereArgs)
    }

    fun deleteEmployee(deleteEmployee: Employee){

        var whereClause = "$COLUMN_ID=?"
        var whereArgs = arrayOf(deleteEmployee.id.toString())

        database.delete(TABLE_NAME, whereClause, whereArgs)
    }

}