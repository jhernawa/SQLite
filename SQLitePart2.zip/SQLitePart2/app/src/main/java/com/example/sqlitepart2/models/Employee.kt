package com.example.sqlitepart2.models

data class Employee(
    var id: Int,
    var name: String,
    var email: String
)